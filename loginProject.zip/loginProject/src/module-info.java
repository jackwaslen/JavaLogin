/**
 * 
 */
/**
 * @author base
 *
 */
module loginProject {
    requires java.sql;
    requires java.desktop;
}