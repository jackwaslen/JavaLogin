/**
 * 
 */
/**
 * @author base
 *
 */
module sideProject {
    requires java.desktop;
}